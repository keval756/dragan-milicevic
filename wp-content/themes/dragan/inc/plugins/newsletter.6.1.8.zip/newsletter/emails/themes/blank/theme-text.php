<?php
if (!defined('ABSPATH')) exit;
?>
This email requires a modern e-mail reader but you can view the email online here:

{email_url}.

Thank you, <?php echo wp_specialchars_decode(get_option('blogname'), ENT_QUOTES); ?>

To change your subscription follow:
{profile_url}.