<?php
if (!defined('ABSPATH')) exit;
?>
<h3>Social icons</h3>
<table class="form-table">
    <tr>
        <th>Social block</th>
        <td><?php $controls->checkbox('theme_social_disable'); ?> Disable</td>
    </tr>
    <tr>
        <th>Facebook</th>
        <td><?php $controls->text_url('theme_facebook', 30); ?></td>
    </tr>
    <tr>
        <th>Twitter</th>
        <td><?php $controls->text_url('theme_twitter', 30); ?></td>
    </tr>
    <tr>
        <th>Pinterest</th>
        <td><?php $controls->text_url('theme_pinterest', 30); ?></td>
    </tr>
    <tr>
        <th>Google+</th>
        <td><?php $controls->text_url('theme_googleplus', 30); ?></td>
    </tr>
    <tr>
        <th>LinkedIn</th>
        <td><?php $controls->text_url('theme_linkedin', 30); ?></td>
    </tr>
    <tr>
        <th>Tumblr</th>
        <td><?php $controls->text_url('theme_tumblr', 30); ?></td>
    </tr>
    <tr>
        <th>YouTube</th>
        <td><?php $controls->text_url('theme_youtube', 30); ?></td>
    </tr>
    <tr>
        <th>Soundcloud</th>
        <td><?php $controls->text_url('theme_soundcloud', 30); ?></td>
    </tr>
     <tr>
        <th>Instagram</th>
        <td><?php $controls->text_url('theme_instagram', 30); ?></td>
    </tr>
</table>