

<table border="0" cellpadding="0" cellspacing="0" width="500" class="responsive-table" align="center">
    <tr>
        <td>
            <!-- HERO IMAGE -->
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td class="padding-copy tnpc-row-edit" data-type="image">
                        <a href="#" target="_blank">
                            <img src="https://unsplash.it/500/300?image=885" width="500" border="0" alt="Insert alt text here" style="max-width: 100%!important; width: 500px!important; height: auto!important; display: block;" class="img-max">
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <!-- COPY -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td align="center" style="font-size: 25px; color: #333333; padding-top: 30px; font-family: Helvetica, arial, sans-serif; " class="padding-copy tnpc-row-edit" data-type="title">An Awesome Title</td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 20px 0 0 0; font-size: 16px; line-height: 25px; color: #666666; font-family: Helvetica, arial, sans-serif; " class="padding-copy tnpc-row-edit" data-type="text">The judge, by the way, was the King; and as he wore his crown over the wig, (look at the frontispiece if you want to see how he did it,) he did not look at all comfortable, and it was certainly not becoming.</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <!-- BULLETPROOF BUTTON -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="mobile-button-container">
                            <tr>
                                <td align="center" style="padding: 25px 0 0 0;" class="padding-copy">
                                    <table border="0" cellspacing="0" cellpadding="0" class="responsive-table">
                                        <tr>
                                            <td align="center">
                                                <a href="#" target="_blank" style="font-size: 16px; font-family: Helvetica, Arial, sans-serif; font-weight: normal; color: #ffffff; text-decoration: none; background-color: #256F9C; border-top: 15px solid #256F9C; border-bottom: 15px solid #256F9C; border-left: 25px solid #256F9C; border-right: 25px solid #256F9C; border-radius: 3px; -webkit-border-radius: 3px; -moz-border-radius: 3px; display: inline-block;" class="mobile-button tnpc-row-edit" data-type="button">Learn More &rarr;</a></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
