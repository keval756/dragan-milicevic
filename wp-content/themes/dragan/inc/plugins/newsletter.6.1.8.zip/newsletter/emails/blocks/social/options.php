<?php
/* @var $options array contains all the options the current block we're ediging contains */
/* @var $controls NewsletterControls */
/* @var $fields NewsletterFields */
?>

<p>Social profiles can be configured on company info panel.</p>

<?php $fields->block_commons() ?>
